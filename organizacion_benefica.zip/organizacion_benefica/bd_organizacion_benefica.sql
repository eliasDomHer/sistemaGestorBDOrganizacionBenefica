--Creación de base de datos
CREATE DATABASE bd_organizacion_benefica;

USE bd_organizacion_benefica;

--Creación de tablas

CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL
);

CREATE TABLE inventario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    descripcion TEXT,
    cantidad INT NOT NULL,
    ubicacion VARCHAR(255),
    estado VARCHAR(50),
    categoria_id INT,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

CREATE TABLE donaciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    donante VARCHAR(255),
    fecha DATE,
    tipo VARCHAR(255),
    cantidad INT,
    descripcion TEXT
);

CREATE TABLE movimientos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inventario_id INT,
    tipo VARCHAR(50), -- 'entrada' o 'salida'
    cantidad INT,
    fecha DATE,
    FOREIGN KEY (inventario_id) REFERENCES inventario(id)
);

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    rol VARCHAR(50) -- 'admin', 'gestor', etc.
);

-- Creación de usuarios ejemplo:
-- Crear un usuario administrador
INSERT INTO usuarios (nombre, email, contrasena, rol) 
VALUES ('Admin', 'admin@example.com', 'admin_password', 'admin');

-- Crear un usuario normal
INSERT INTO usuarios (nombre, email, contrasena, rol) 
VALUES ('Usuario', 'usuario@example.com', 'user_password', 'usuario');