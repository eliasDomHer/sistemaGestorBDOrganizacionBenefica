<?php
// Datos de conexión a la base de datos
$host = "localhost"; // La dirección del servidor de la base de datos, usualmente "localhost" significa el mismo servidor donde se está ejecutando el código.
$usuario = "root"; // El nombre de usuario para conectarse a la base de datos. "root" es el nombre por defecto para muchos sistemas de bases de datos.
$contrasena = ""; // La contraseña para el usuario de la base de datos. En este caso está vacía, pero debería ser segura en una aplicación real.
$base_datos = "bd_organizacion_benefica"; // El nombre de la base de datos a la que queremos conectarnos.


// Verificar si la sesión no está ya activa antes de modificar los parámetros de la cookie
$sesion_vida = 1800; // Duración de la sesión en segundos (30 minutos).
if (session_status() == PHP_SESSION_NONE) {
    // Establecer un tiempo de vida para la sesión en segundos (por ejemplo, 30 minutos)
    session_set_cookie_params($sesion_vida);
    session_start(); // Iniciar la sesión si no está ya iniciada.
}

// Conectar a la base de datos
$conexion = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verificar si hay errores de conexión
if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error); // Si hay un error, mostrar un mensaje y detener el script.
}

// Establecer el juego de caracteres a UTF-8 (opcional)
$conexion->set_charset("utf8"); // Asegurarse de que la comunicación con la base de datos use el conjunto de caracteres UTF-8.

// Aquí puedes incluir más configuraciones de conexión si las necesitas

// Actualizar el tiempo de vida de la sesión
if (isset($_SESSION['usuario_id'])) {
    $_SESSION['ultimo_acceso'] = time(); // Registrar el tiempo actual como el último acceso del usuario.
}

// Verificar si la sesión ha expirado
if (isset($_SESSION['ultimo_acceso']) && (time() - $_SESSION['ultimo_acceso']) > $sesion_vida) {
    // Si ha pasado más tiempo del permitido, destruir la sesión
    session_unset(); // Eliminar todas las variables de sesión.
    session_destroy(); // Destruir la sesión.
}

// Función para actualizar el inventario
function actualizarInventario($conexion, $articulo_id, $cantidad) {
    // Crear la consulta SQL para actualizar la cantidad de un artículo en el inventario.
    $query = "UPDATE articulos SET cantidad = cantidad + ? WHERE id = ?";
    $stmt = $conexion->prepare($query); // Preparar la consulta.
    $stmt->bind_param("ii", $cantidad, $articulo_id); // Vincular los parámetros a la consulta (cantidad y ID del artículo).
    $stmt->execute(); // Ejecutar la consulta.
    // Registrar el movimiento de inventario.
    registrarMovimiento($conexion, $articulo_id, $cantidad > 0 ? 'entrada' : 'salida', abs($cantidad));
}

// Función para registrar un movimiento en el inventario
function registrarMovimiento($conexion, $articulo_id, $tipo, $cantidad) {
    // Crear la consulta SQL para insertar un nuevo movimiento de inventario.
    $query = "INSERT INTO movimientos_inventario (articulo_id, tipo, cantidad) VALUES (?, ?, ?)";
    $stmt = $conexion->prepare($query); // Preparar la consulta.
    $stmt->bind_param("isi", $articulo_id, $tipo, $cantidad); // Vincular los parámetros a la consulta (ID del artículo, tipo de movimiento, cantidad).
    $stmt->execute(); // Ejecutar la consulta.
}
