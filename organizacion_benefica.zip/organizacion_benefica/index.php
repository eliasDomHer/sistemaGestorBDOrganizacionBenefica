<?php
// Inicia una nueva sesión o reanuda la existente
session_start(); 

// Verifica si la variable de sesión 'usuario_id' está establecida
// Esto comprueba si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Si el usuario no ha iniciado sesión, redirige a la página de login
    header("Location: pages/login.php");
    // Termina el script para asegurarse de que no se ejecute más código
    exit;
}

// Verifica si se ha enviado una solicitud POST con el nombre 'cerrar_sesion'
if (isset($_POST['cerrar_sesion'])) {
    // Destruye la sesión actual, cerrando la sesión del usuario
    session_destroy();
    // Redirige a la página de login después de cerrar la sesión
    header("Location: pages/login.php");
    // Termina el script para asegurarse de que no se ejecute más código
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Inventario</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }

        /* header {
            background-color: #4CAF50;
            color: white;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        nav ul li {
            float: left;
        }

        nav ul li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        nav ul li a:hover {
            background-color: #111;
        }

        nav ul li form {
            display: inline;
        }

        nav ul li form button {
            display: block;
            background-color: #333;
            color: white;
            text-align: center;
            padding: 14px 16px;
            border: none;
            cursor: pointer;
        }

        nav ul li form button:hover {
            background-color: #111;
        } */

        main {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 60px); /* Resta el tamaño del header y el nav */
        }

        .background-collage {
            position: fixed;
            top: 60px; /* Debajo del header */
            left: 0;
            width: 100%;
            height: calc(100% - 60px); /* Resta el tamaño del header */
            z-index: -1;
            background: url('https://images.pexels.com/photos/6646847/pexels-photo-6646847.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1') no-repeat center center fixed; /* Ruta del collage de fotos */
            background-size: cover;
            filter: blur(8px) brightness(70%);
        }

        .charity-message {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .charity-message h2 {
            margin: 0;
            font-size: 2em;
            color: #333;
        }
    </style>
</head>
<body>
    <header>
        <h1>Gestión de Inventario</h1>
    </header>
    <nav>
        <ul>
            <li><a href="pages/inventario.php">Inventario</a></li>
            <li><a href="pages/donaciones.php">Donaciones</a></li>
            <li><a href="pages/reportes.php">Reportes</a></li>
            <li><a href="pages/usuarios.php">Usuarios</a></li>
            <li>
                <form action="" method="post">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </li>
        </ul>
    </nav>
    <main>
        <div class="background-collage"></div>
        <div class="charity-message">
            <h2>Un pequeño gesto de caridad puede cambiar muchas vidas.</h2>
        </div>
    </main>
</body>
</html>
