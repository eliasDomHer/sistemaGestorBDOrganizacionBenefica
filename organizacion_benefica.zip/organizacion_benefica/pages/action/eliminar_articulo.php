<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $articulo_id = $_POST["articulo_id"];

    $query = "DELETE FROM articulos WHERE id = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("i", $articulo_id);
    $stmt->execute();
    
    header("Location: inventario.php");
    exit;
}
?>
