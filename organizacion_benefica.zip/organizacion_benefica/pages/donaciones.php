<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

// Verificar si el usuario es administrador
$isAdmin = $_SESSION['usuario_rol'] == 'admin';

// Manejar el formulario de recepción de donaciones
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'recepcion') {
    $donante = $_POST["donante"];
    $fecha_donacion = $_POST["fecha_donacion"];
    $tipo_articulo = $_POST["tipo_articulo"];
    $cantidad = $_POST["cantidad"];
    $articulo_id = $_POST["articulo_id"];

    $query = "INSERT INTO donaciones (donante, fecha_donacion, tipo_articulo, cantidad, articulo_id) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("sssis", $donante, $fecha_donacion, $tipo_articulo, $cantidad, $articulo_id);
    $stmt->execute();

    actualizarInventario($conexion, $articulo_id, $cantidad);

    header("Location: donaciones.php");
    exit;
}

// Manejar el formulario de realización de donaciones
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'realizacion') {
    $donante = $_POST["donante"];
    $fecha_donacion = $_POST["fecha_donacion"];
    $tipo_articulo = $_POST["tipo_articulo"];
    $cantidad = $_POST["cantidad"];
    $articulo_id = $_POST["articulo_id"];
    $motivo = $_POST["motivo"];

    $query = "INSERT INTO donaciones (donante, fecha_donacion, tipo_articulo, cantidad, articulo_id, motivo) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("sssiss", $donante, $fecha_donacion, $tipo_articulo, $cantidad, $articulo_id, $motivo);
    $stmt->execute();

    actualizarInventario($conexion, $articulo_id, -$cantidad);

    header("Location: donaciones.php");
    exit;
}

// Obtener los artículos del inventario
$articulos = $conexion->query("SELECT * FROM articulos");

// Obtener las donaciones
$donaciones = $conexion->query("SELECT donaciones.*, articulos.nombre AS articulo FROM donaciones 
    LEFT JOIN articulos ON donaciones.articulo_id = articulos.id");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Donaciones</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            text-align: left;
        }

        .form-section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-section label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-section input[type="text"],
        .form-section input[type="date"],
        .form-section input[type="number"],
        .form-section textarea,
        .form-section select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-section button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-section button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        nav ul {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <h1>Donaciones</h1>
        <nav>
            <ul>
                <li><a href="inventario.php">Inventario</a></li>
                <li><a href="donaciones.php">Donaciones</a></li>
                <li><a href="donaciones_economicas.php">Donaciones Económicas</a></li>
                <li><a href="reportes.php">Reportes</a></li>
                <li><a href="usuarios.php">Usuarios</a></li>
                <form action="../index.php" method="post" style="display:inline;">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </ul>
        </nav>
    </header>
    <main>
        <div class="form-section">
            <h2>Recepción de Donaciones</h2>
            <form action="donaciones.php" method="post">
                <input type="hidden" name="accion" value="recepcion">
                <label for="donante">Donante:</label>
                <input type="text" name="donante" id="donante" required>
                <label for="fecha_donacion">Fecha de Donación:</label>
                <input type="date" name="fecha_donacion" id="fecha_donacion" required>
                <label for="tipo_articulo">Tipo de Artículo:</label>
                <input type="text" name="tipo_articulo" id="tipo_articulo" required>
                <label for="articulo_id">Artículo:</label>
                <select name="articulo_id" id="articulo_id" required>
                    <?php while ($articulo = $articulos->fetch_assoc()) { ?>
                        <option value="<?php echo $articulo['id']; ?>"><?php echo $articulo['nombre']; ?></option>
                    <?php } ?>
                </select>
                <label for="cantidad">Cantidad:</label>
                <input type="number" name="cantidad" id="cantidad" required>
                <button type="submit">Registrar Donación</button>
            </form>
        </div>

        <div class="form-section">
            <h2>Realización de Donaciones</h2>
            <form action="donaciones.php" method="post">
                <input type="hidden" name="accion" value="realizacion">
                <label for="donante">Donante:</label>
                <input type="text" name="donante" id="donante" required>
                <label for="fecha_donacion">Fecha de Donación:</label>
                <input type="date" name="fecha_donacion" id="fecha_donacion" required>
                <label for="tipo_articulo">Tipo de Artículo:</label>
                <input type="text" name="tipo_articulo" id="tipo_articulo" required>
                <label for="articulo_id">Artículo:</label>
                <select name="articulo_id" id="articulo_id" required>
                    <?php
                    $articulos->data_seek(0);
                    while ($articulo = $articulos->fetch_assoc()) { ?>
                        <option value="<?php echo $articulo['id']; ?>"><?php echo $articulo['nombre']; ?></option>
                    <?php } ?>
                </select>
                <label for="cantidad">Cantidad:</label>
                <input type="number" name="cantidad" id="cantidad" required>
                <label for="motivo">Motivo:</label>
                <input type="text" name="motivo" id="motivo" required>
                <button type="submit">Registrar Donación</button>
            </form>
        </div>

        <h2>Historial de Donaciones</h2>
        <table>
            <thead>
                <tr>
                    <th>Donante</th>
                    <th>Fecha</th>
                    <th>Tipo de Artículo</th>
                    <th>Artículo</th>
                    <th>Cantidad</th>
                    <th>Motivo</th>
                    <th>Tipo</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($donacion = $donaciones->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $donacion['donante']; ?></td>
                        <td><?php echo $donacion['fecha_donacion']; ?></td>
                        <td><?php echo $donacion['tipo_articulo']; ?></td>
                        <td><?php echo $donacion['articulo']; ?></td>
                        <td><?php echo $donacion['cantidad']; ?></td>
                        <td><?php echo isset($donacion['motivo']) ? $donacion['motivo'] : 'Recepción'; ?></td>
                        <td><?php echo isset($donacion['motivo']) ? 'Realización' : 'Recepción'; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
</body>
</html>
