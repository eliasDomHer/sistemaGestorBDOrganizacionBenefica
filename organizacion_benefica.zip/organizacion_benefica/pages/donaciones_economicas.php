<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

// Manejar el formulario de recepción de donaciones económicas
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion'])) {
    $tipo_transaccion = $_POST["tipo_transaccion"];
    $monto = $_POST["monto"];
    $fecha_donacion = $_POST["fecha_donacion"];
    $descripcion = $_POST["descripcion"];

    // Ingresar las donaciones económicas en la base de datos
    $query = "INSERT INTO donaciones_economicas (tipo_transaccion, monto, fecha_donacion, descripcion) VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("sdss", $tipo_transaccion, $monto, $fecha_donacion, $descripcion);
    $stmt->execute();

    header("Location: donaciones_economicas.php");
    exit;
}

// Obtener las donaciones económicas
$donaciones_economicas = $conexion->query("SELECT * FROM donaciones_economicas");

// Calcular el total en caja
$total_ingresos = 0;
$total_egresos = 0;

while ($donacion = $donaciones_economicas->fetch_assoc()) {
    if ($donacion['tipo_transaccion'] == 'Ingreso') {
        $total_ingresos += $donacion['monto'];
    } else {
        $total_egresos += $donacion['monto'];
    }
}

$total_en_caja = $total_ingresos - $total_egresos;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Donaciones Económicas</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            text-align: left;
        }

        .form-section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-section label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-section input[type="text"],
        .form-section input[type="date"],
        .form-section input[type="number"],
        .form-section textarea,
        .form-section select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-section button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-section button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        nav ul {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <h1>Donaciones Económicas</h1>
        <nav>
            <ul>
                <li><a href="inventario.php">Inventario</a></li>
                <li><a href="donaciones.php">Donaciones</a></li>
                <li><a href="donaciones_economicas.php">Donaciones Económicas</a></li>
                <li><a href="reportes.php">Reportes</a></li>
                <li><a href="usuarios.php">Usuarios</a></li>
                <form action="../index.php" method="post" style="display:inline;">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </ul>
        </nav>
    </header>
    <main>
        <!-- Mostrar el total en caja -->
        <div class="saldo-section">
            <h2>Total en Caja: $<?php echo number_format($total_en_caja, 2); ?></h2>
        </div>

        <!-- Formulario para Ingresar Donaciones Económicas -->
        <div class="form-section">
            <h2>Registrar Donaciones Económicas</h2>
            <form action="donaciones_economicas.php" method="post">
                <label for="tipo_transaccion">Tipo de Transacción:</label>
                <select name="tipo_transaccion" id="tipo_transaccion" required>
                    <option value="Ingreso">Ingreso</option>
                    <option value="Egreso">Egreso</option>
                </select>

                <label for="monto">Monto (MXN):</label>
                <input type="number" name="monto" id="monto" step="0.01" required>

                <label for="fecha_donacion">Fecha:</label>
                <input type="date" name="fecha_donacion" id="fecha_donacion" required>

                <label for="descripcion">Descripción:</label>
                <textarea name="descripcion" id="descripcion" required></textarea>

                <button type="submit" name="accion" value="registro">Registrar Donación</button>
            </form>
        </div>

        <!-- Historial de Donaciones Económicas -->
        <h2>Historial de Donaciones Económicas</h2>
        <table>
            <thead>
                <tr>
                    <th>Tipo de Transacción</th>
                    <th>Monto</th>
                    <th>Fecha</th>
                    <th>Descripción</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Reiniciar la consulta para mostrar el historial
                $donaciones_economicas->data_seek(0); // Volver al inicio del conjunto de resultados
                while ($donacion = $donaciones_economicas->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $donacion['tipo_transaccion']; ?></td>
                        <td><?php echo $donacion['monto']; ?></td>
                        <td><?php echo $donacion['fecha_donacion']; ?></td>
                        <td><?php echo $donacion['descripcion']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
</body>
</html>
