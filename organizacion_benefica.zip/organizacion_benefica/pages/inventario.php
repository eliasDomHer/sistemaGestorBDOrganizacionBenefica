<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

// Verificar si el usuario es administrador
$isAdmin = $_SESSION['usuario_rol'] == 'admin';

// Manejar el formulario de agregar/editar artículo
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'articulo') {
    $nombre = $_POST["nombre"];
    $descripcion = $_POST["descripcion"];
    $categoria_id = $_POST["categoria_id"];
    $subcategoria_id = $_POST["subcategoria_id"];
    $cantidad = $_POST["cantidad"];
    $ubicacion = $_POST["ubicacion"];
    $estado = $_POST["estado"];
    $stock_minimo = $_POST["stock_minimo"];
    $articulo_id = isset($_POST["articulo_id"]) ? $_POST["articulo_id"] : null;

    if ($articulo_id) {
        // Actualizar artículo existente
        $query = "UPDATE articulos SET nombre=?, descripcion=?, categoria_id=?, subcategoria_id=?, cantidad=?, ubicacion=?, estado=?, stock_minimo=? WHERE id=?";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("ssiiissii", $nombre, $descripcion, $categoria_id, $subcategoria_id, $cantidad, $ubicacion, $estado, $stock_minimo, $articulo_id);
        $stmt->execute();
        registrarMovimiento($conexion, $articulo_id, 'entrada', $cantidad);
    } else {
        // Insertar nuevo artículo
        $query = "INSERT INTO articulos (nombre, descripcion, categoria_id, subcategoria_id, cantidad, ubicacion, estado, stock_minimo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("ssiiissi", $nombre, $descripcion, $categoria_id, $subcategoria_id, $cantidad, $ubicacion, $estado, $stock_minimo);
        $stmt->execute();
        $nuevo_articulo_id = $stmt->insert_id;
        registrarMovimiento($conexion, $nuevo_articulo_id, 'entrada', $cantidad);
    }
    header("Location: inventario.php");
    exit;
}

// Manejar el formulario de agregar categoría
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'categoria') {
    $nombre_categoria = $_POST["nombre_categoria"];

    $query = "INSERT INTO categorias (nombre) VALUES (?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("s", $nombre_categoria);
    $stmt->execute();
    header("Location: inventario.php");
    exit;
}

// Manejar el formulario de agregar subcategoría
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'subcategoria') {
  $nombre_subcategoria = $_POST["nombre_subcategoria"];
  $categoria_id = $_POST["categoria_id_sub"];

  $query = "INSERT INTO subcategorias (nombre, categoria_id) VALUES (?, ?)";
  $stmt = $conexion->prepare($query);
  $stmt->bind_param("si", $nombre_subcategoria, $categoria_id);
  $stmt->execute();

  // Después de insertar la subcategoría, obtener las categorías nuevamente
  $categorias_sub = $conexion->query("SELECT * FROM categorias");
  mysqli_data_seek($categorias_sub, 0); // Reiniciar el puntero del resultado

  header("Location: inventario.php");
  exit;
}

// Obtener las categorías y subcategorías
$categorias = $conexion->query("SELECT * FROM categorias");
$categorias2 = $conexion->query("SELECT * FROM categorias");
// Reiniciar el puntero del resultado para poder iterar sobre él nuevamente
mysqli_data_seek($categorias, 0);
$subcategorias = $conexion->query("SELECT * FROM subcategorias");

// Obtener los artículos del inventario
$articulos = $conexion->query("SELECT articulos.*, categorias.nombre AS categoria, subcategorias.nombre AS subcategoria FROM articulos 
    LEFT JOIN categorias ON articulos.categoria_id = categorias.id 
    LEFT JOIN subcategorias ON articulos.subcategoria_id = subcategorias.id");

// Ordenar los artículos del inventario
if(isset($_GET['orden'])) {
    $orden = $_GET['orden'];
    switch ($orden) {
        case 'categoria':
            $order_clause = 'categorias.nombre, subcategorias.nombre';
            break;
        case 'subcategoria':
            $order_clause = 'subcategorias.nombre, categorias.nombre';
            break;
        case 'nombre':
            $order_clause = 'articulos.nombre';
            break;
        case 'estado':
            $order_clause = 'articulos.estado';
            break;
        case 'ubicacion':
            $order_clause = 'articulos.ubicacion';
            break;
        default:
            $order_clause = 'articulos.id'; // Orden por defecto
            break;
    }
} else {
    $order_clause = 'articulos.id'; // Orden por defecto
}

$articulos = $conexion->query("SELECT articulos.*, categorias.nombre AS categoria, subcategorias.nombre AS subcategoria FROM articulos 
    LEFT JOIN categorias ON articulos.categoria_id = categorias.id 
    LEFT JOIN subcategorias ON articulos.subcategoria_id = subcategorias.id
    ORDER BY $order_clause");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            text-align: left;
        }

        .form-section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-section label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-section input[type="text"],
        .form-section input[type="number"],
        .form-section textarea,
        .form-section select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-section button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-section button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
            cursor: pointer;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions button {
            background-color: #007BFF;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-right: 5px;
        }

        .actions button:hover {
            background-color: #0056b3;
        }

        .actions form {
            display: inline;
        }

        .actions form button {
            background-color: #dc3545;
        }

        .actions form button:hover {
            background-color: #c82333;
        }

        .stock-bajo {
            color: red;
            font-weight: bold;
        }
        /********************************* */
        nav ul {
            display: block;
        }

        td form {
        display: inline;
        margin-left: 0px;
        box-shadow: none;
        background-color: transparent;
        padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Inventario</h1>
        <nav>
            <ul>
                <li><a href="inventario.php">Inventario</a></li>
                <li><a href="donaciones.php">Donaciones</a></li>
                <li><a href="donaciones_economicas.php">Donaciones Económicas</a></li>
                <li><a href="reportes.php">Reportes</a></li>
                <li><a href="usuarios.php">Usuarios</a></li>
                <form action="../index.php" method="post" style="display:inline;">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </ul>
        </nav>
    </header>
    <main>
        <div class="form-section">
            <h2>Agregar/Editar Artículo</h2>
            <form action="inventario.php" method="post">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>

                <label for="descripcion">Descripción:</label>
                <textarea id="descripcion" name="descripcion" required></textarea>

                <label for="categoria_id">Categoría:</label>
                <select id="categoria_id" name="categoria_id" required>
                    <?php while ($row = $categorias->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
                    <?php endwhile; ?>
                </select>

                <label for="subcategoria_id">Subcategoría:</label>
                <select id="subcategoria_id" name="subcategoria_id" required>
                    <?php while ($row = $subcategorias->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
                    <?php endwhile; ?>
                </select>

                <label for="cantidad">Cantidad:</label>
                <input type="number" id="cantidad" name="cantidad" required>

                <label for="ubicacion">Ubicación:</label>
                <input type="text" id="ubicacion" name="ubicacion" required>

                <label for="estado">Estado:</label>
                <input type="text" id="estado" name="estado" required>

                <label for="stock_minimo">Stock Mínimo:</label>
                <input type="number" id="stock_minimo" name="stock_minimo" required>

                <input type="hidden" name="articulo_id" id="articulo_id">
                <input type="hidden" name="accion" value="articulo">
                <button type="submit">Guardar</button>
            </form>
        </div>

        <?php if ($isAdmin): ?>
            <div class="form-section">
                <h2>Agregar Categoría</h2>
                <form action="inventario.php" method="post">
                    <label for="nombre_categoria">Nombre de la Categoría:</label>
                    <input type="text" id="nombre_categoria" name="nombre_categoria" required>
                    <input type="hidden" name="accion" value="categoria">
                    <button type="submit">Agregar Categoría</button>
                </form>
            </div>

            <div class="form-section">
                <h2>Agregar Subcategoría</h2>
                <form action="inventario.php" method="post">
                    <label for="categoria_id_sub">Categoría:</label>
                    <select id="categoria_id_sub" name="categoria_id_sub" required>
                        <?php while ($row = $categorias2->fetch_assoc()): ?>
                            <option value="<?php echo $row['id']; ?>"><?php echo $row['nombre']; ?></option>
                        <?php endwhile; ?>
                    </select>
                    <label for="nombre_subcategoria">Nombre de la Subcategoría:</label>
                    <input type="text" id="nombre_subcategoria" name="nombre_subcategoria" required>
                    <input type="hidden" name="accion" value="subcategoria">
                    <button type="submit">Agregar Subcategoría</button>
                </form>
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th onclick="ordenar('categoria')">Categoría</th>
                    <th onclick="ordenar('subcategoria')">Subcategoría</th>
                    <th onclick="ordenar('nombre')">Nombre</th>
                    <th onclick="ordenar('estado')">Estado</th>
                    <th onclick="ordenar('ubicacion')">Ubicación</th>
                    <th>Cantidad</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $articulos->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row["categoria"]; ?></td>
                        <td><?php echo $row["subcategoria"]; ?></td>
                        <td><?php echo $row["nombre"]; ?></td>
                        <td><?php echo $row["estado"]; ?></td>
                        <td><?php echo $row["ubicacion"]; ?></td>
                        <td class="<?php echo ($row["cantidad"] < $row["stock_minimo"]) ? 'stock-bajo' : ''; ?>"><?php echo $row["cantidad"]; ?></td>
                        <td class="actions">
                            <button onclick="editarArticulo('<?php echo $row['id']; ?>', '<?php echo $row['nombre']; ?>', '<?php echo $row['descripcion']; ?>', '<?php echo $row['categoria_id']; ?>', '<?php echo $row['subcategoria_id']; ?>', '<?php echo $row['cantidad']; ?>', '<?php echo $row['ubicacion']; ?>', '<?php echo $row['estado']; ?>', '<?php echo $row['stock_minimo']; ?>')">Editar</button>
                            <form action="eliminar_articulo.php" method="post" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este artículo?');">
                                <input type="hidden" name="articulo_id" value="<?php echo $row['id']; ?>">
                                <button type="submit">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </main>

    <script>
        function editarArticulo(id, nombre, descripcion, categoria_id, subcategoria_id, cantidad, ubicacion, estado, stock_minimo) {
            document.getElementById('articulo_id').value = id;
            document.getElementById('nombre').value = nombre;
            document.getElementById('descripcion').value = descripcion;
            document.getElementById('categoria_id').value = categoria_id;
            document.getElementById('subcategoria_id').value = subcategoria_id;
            document.getElementById('cantidad').value = cantidad;
            document.getElementById('ubicacion').value = ubicacion;
            document.getElementById('estado').value = estado;
            document.getElementById('stock_minimo').value = stock_minimo;
        }

        function ordenar(criterio) {
            window.location.href = 'inventario.php?orden=' + criterio;
        }
    </script>
</body>
</html>
