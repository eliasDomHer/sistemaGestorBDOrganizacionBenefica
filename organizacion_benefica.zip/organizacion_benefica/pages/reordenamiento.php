<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

$articulos_bajo_stock = $conexion->query("SELECT * FROM articulos WHERE cantidad < stock_minimo");

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reordenamiento Automático</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <h1>Reordenamiento Automático</h1>
        <nav>
            <a href="inventario.php">Inventario</a>
            <a href="donaciones.php">Donaciones</a>
            <a href="reportes.php">Reportes</a>
            <a href="usuarios.php">Usuarios</a>
            <form action="../index.php" method="post" style="display:inline;">
                <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
            </form>
        </nav>
    </header>
    <main>
        <h2>Artículos con Stock Bajo</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Cantidad</th>
                    <th>Stock Mínimo</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($articulo = $articulos_bajo_stock->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $articulo['nombre']; ?></td>
                        <td><?php echo $articulo['cantidad']; ?></td>
                        <td><?php echo $articulo['stock_minimo']; ?></td>
                        <td><a href="reordenar.php?articulo_id=<?php echo $articulo['id']; ?>">Reordenar</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
</body>
</html>
