<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

// Obtener el estado del inventario
$inventario = $conexion->query("SELECT articulos.*, categorias.nombre AS categoria, subcategorias.nombre AS subcategoria FROM articulos 
    LEFT JOIN categorias ON articulos.categoria_id = categorias.id 
    LEFT JOIN subcategorias ON articulos.subcategoria_id = subcategorias.id");

// Obtener los movimientos de artículos (donaciones)
$movimientos = $conexion->query("SELECT donaciones.*, articulos.nombre AS articulo_nombre FROM donaciones 
    LEFT JOIN articulos ON donaciones.articulo_id = articulos.id");

// Obtener las tendencias de donaciones (por rango de fechas)
$tendencias_donaciones = [];
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'tendencias_donaciones') {
    $fecha_inicio = $_POST["fecha_inicio"];
    $fecha_fin = $_POST["fecha_fin"];

    $query = "SELECT donaciones.*, articulos.nombre AS articulo_nombre FROM donaciones 
        LEFT JOIN articulos ON donaciones.articulo_id = articulos.id
        WHERE fecha_donacion BETWEEN ? AND ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ss", $fecha_inicio, $fecha_fin);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $tendencias_donaciones[] = $row;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Reportes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            text-align: left;
        }

        .form-section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-section label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-section input[type="text"],
        .form-section input[type="date"],
        .form-section input[type="number"],
        .form-section textarea,
        .form-section select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-section button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-section button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
            cursor: pointer;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions button {
            background-color: #007BFF;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-right: 5px;
        }

        .actions button:hover {
            background-color: #0056b3;
        }

        .actions form {
            display: inline;
        }

        .actions form button {
            background-color: #dc3545;
        }

        .actions form button:hover {
            background-color: #c82333;
        }

        .stock-bajo {
            color: red;
            font-weight: bold;
        }
         /*********************** */
         nav ul {
            display: block;
        }

        td form {
        display: inline;
        margin-left: 0px;
        box-shadow: none;
        background-color: transparent;
        padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Reportes</h1>
        <nav>
            <ul>
                <li><a href="inventario.php">Inventario</a></li>
                <li><a href="donaciones.php">Donaciones</a></li>
                <li><a href="donaciones_economicas.php">Donaciones Económicas</a></li>
                <li><a href="reportes.php">Reportes</a></li>
                <li><a href="usuarios.php">Usuarios</a></li>
                <form action="../index.php" method="post" style="display:inline;">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Estado del Inventario</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Categoría</th>
                    <th>Subcategoría</th>
                    <th>Cantidad</th>
                    <th>Ubicación</th>
                    <th>Estado</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($articulo = $inventario->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $articulo['nombre']; ?></td>
                        <td><?php echo $articulo['descripcion']; ?></td>
                        <td><?php echo $articulo['categoria']; ?></td>
                        <td><?php echo $articulo['subcategoria']; ?></td>
                        <td><?php echo $articulo['cantidad']; ?></td>
                        <td><?php echo $articulo['ubicacion']; ?></td>
                        <td><?php echo $articulo['estado']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <h2>Movimientos de Artículos</h2>
        <table>
            <thead>
                <tr>
                    <th>Donante</th>
                    <th>Fecha de Donación</th>
                    <th>Tipo de Artículo</th>
                    <th>Cantidad</th>
                    <th>Artículo</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($movimiento = $movimientos->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $movimiento['donante']; ?></td>
                        <td><?php echo $movimiento['fecha_donacion']; ?></td>
                        <td><?php echo $movimiento['tipo_articulo']; ?></td>
                        <td><?php echo $movimiento['cantidad']; ?></td>
                        <td><?php echo $movimiento['articulo_nombre']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <h2>Tendencias de Donaciones</h2>
        <div class="form-section">
            <form action="reportes.php" method="post">
                <input type="hidden" name="accion" value="tendencias_donaciones">
                <label for="fecha_inicio">Fecha de Inicio:</label>
                <input type="date" name="fecha_inicio" id="fecha_inicio" required>
                <label for="fecha_fin">Fecha de Fin:</label>
                <input type="date" name="fecha_fin" id="fecha_fin" required>
                <button type="submit">Generar Reporte</button>
            </form>
        </div>

        <?php if (!empty($tendencias_donaciones)) { ?>
            <h3>Resultados de Donaciones</h3>
            <table>
                <thead>
                    <tr>
                        <th>Donante</th>
                        <th>Fecha de Donación</th>
                        <th>Tipo de Artículo</th>
                        <th>Cantidad</th>
                        <th>Artículo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tendencias_donaciones as $donacion) { ?>
                        <tr>
                            <td><?php echo $donacion['donante']; ?></td>
                            <td><?php echo $donacion['fecha_donacion']; ?></td>
                            <td><?php echo $donacion['tipo_articulo']; ?></td>
                            <td><?php echo $donacion['cantidad']; ?></td>
                            <td><?php echo $donacion['articulo_nombre']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } ?>
    </main>
</body>
</html>
