<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] != 'admin') {
    header("Location: login.php");
    exit;
}

require_once("../includes/bd.php");

// Manejar el formulario de agregar/editar usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'usuario') {
    $nombre = $_POST["nombre"];
    $email = $_POST["email"];
    $rol = $_POST["rol"];
    $usuario_id = isset($_POST["usuario_id"]) ? $_POST["usuario_id"] : null;

    if ($usuario_id) {
        // Actualizar usuario existente
        if (!empty($_POST["contrasena"])) {
            $contrasena = password_hash($_POST["contrasena"], PASSWORD_DEFAULT);
            $query = "UPDATE usuarios SET nombre=?, email=?, contrasena=?, rol=? WHERE id=?";
            $stmt = $conexion->prepare($query);
            $stmt->bind_param("ssssi", $nombre, $email, $contrasena, $rol, $usuario_id);
        } else {
            $query = "UPDATE usuarios SET nombre=?, email=?, rol=? WHERE id=?";
            $stmt = $conexion->prepare($query);
            $stmt->bind_param("sssi", $nombre, $email, $rol, $usuario_id);
        }
    } else {
        // Insertar nuevo usuario
        $contrasena = password_hash($_POST["contrasena"], PASSWORD_DEFAULT);
        $query = "INSERT INTO usuarios (nombre, email, contrasena, rol) VALUES (?, ?, ?, ?)";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("ssss", $nombre, $email, $contrasena, $rol);
    }
    $stmt->execute();
    header("Location: usuarios.php");
    exit;
}

// Manejar la eliminación de usuario
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'eliminar_usuario') {
    $usuario_id = $_POST["usuario_id"];

    $query = "DELETE FROM usuarios WHERE id=?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    header("Location: usuarios.php");
    exit;
}

// Obtener la lista de usuarios
$usuarios = $conexion->query("SELECT * FROM usuarios");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-section {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            text-align: left;
        }

        .form-section h2 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }

        .form-section label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        .form-section input[type="text"],
        .form-section input[type="email"],
        .form-section input[type="password"],
        .form-section select {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-section button {
            background-color: #4CAF50;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-section button:hover {
            background-color: #45a049;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        table th {
            background-color: #f4f4f4;
            font-weight: bold;
            cursor: pointer;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .actions button {
            background-color: #007BFF;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-right: 5px;
        }

        .actions button:hover {
            background-color: #0056b3;
        }

        .actions form {
            display: inline;
        }

        .actions form button {
            background-color: #dc3545;
        }

        .actions form button:hover {
            background-color: #c82333;
        }
         /*********************** */
         nav ul {
            display: block;
        }

        td form {
        display: inline;
        margin-left: 0px;
        box-shadow: none;
        background-color: transparent;
        padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Usuarios</h1>
        <nav>
            <ul>
                <li><a href="inventario.php">Inventario</a></li>
                <li><a href="donaciones.php">Donaciones</a></li>
                <li><a href="donaciones_economicas.php">Donaciones Económicas</a></li>
                <li><a href="reportes.php">Reportes</a></li>
                <li><a href="usuarios.php">Usuarios</a></li>
                <form action="../index.php" method="post" style="display:inline;">
                    <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
                </form>
            </ul>
        </nav>
    </header>
    <main>
        <div class="form-section">
            <h2>Agregar/Editar Usuario</h2>
            <form action="usuarios.php" method="post">
                <input type="hidden" name="accion" value="usuario">
                <input type="hidden" name="usuario_id" id="usuario_id">
                <label for="nombre">Nombre:</label>
                <input type="text" name="nombre" id="nombre" required>
                <label for="email">Correo:</label>
                <input type="email" name="email" id="email" required>
                <label for="rol">Rol:</label>
                <select name="rol" id="rol" required>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>
                <label for="contrasena">Contraseña:</label>
                <input type="password" name="contrasena" id="contrasena">
                <button type="submit">Guardar</button>
            </form>
        </div>

        <h2>Lista de Usuarios</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($usuario = $usuarios->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($usuario['nombre'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars(isset($usuario['email']) ? $usuario['email'] : '', ENT_QUOTES, 'UTF-8'); ?></td>
                        <td><?php echo htmlspecialchars($usuario['rol'], ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>
                            <button onclick="editarUsuario(<?php echo htmlspecialchars(json_encode($usuario), ENT_QUOTES, 'UTF-8'); ?>)">Editar</button>
                            <form action="usuarios.php" method="post" style="display:inline;">
                                <input type="hidden" name="accion" value="eliminar_usuario">
                                <input type="hidden" name="usuario_id" value="<?php echo $usuario['id']; ?>">
                                <button type="submit" onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?');">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>
    <script>
        function editarUsuario(usuario) {
            document.getElementById('usuario_id').value = usuario.id;
            document.getElementById('nombre').value = usuario.nombre;
            document.getElementById('email').value = usuario.email || ''; // Validar si 'email' está definido
            document.getElementById('rol').value = usuario.rol;
            document.getElementById('contrasena').removeAttribute('required');
        }
    </script>
</body>
</html>
